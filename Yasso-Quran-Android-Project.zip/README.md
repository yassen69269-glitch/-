# Yasso Quran Android wrapper

This Android project opens the published Whacka Yasso Quran website in a WebView.

## Build APK on GitHub (phone-friendly)
1. Create a GitHub repository named `Yasso-Quran`.
2. Upload the **contents** of this ZIP to the repository root (the `.github` folder must also be uploaded).
3. Commit to the `main` branch.
4. Open the repository's **Actions** tab and wait for **Build Yasso Quran APK** to finish.
5. Open the successful workflow run, scroll to **Artifacts**, and download `Yasso-Quran-debug-apk`.
6. Extract the ZIP artifact and install `app-debug.apk` on Android.

The app asks for microphone permission when the website requests audio capture. Android will still require the user to approve that permission.

Important: this is a WebView wrapper, not a copy of Whacka's source code. It requires the published website to remain online. Features that Whacka blocks or that require native integration may not work inside the wrapper.
